# PETAVU — پِتاو

**نسخهٔ ۰٫۱: طراحی اجرایی و زیرساخت اولیه، نه سامانهٔ production.**

شبکهٔ همکاری B2B برای کسب‌وکارهای پت و اسب: پت‌شاپ، دامپزشکی، مراکز اسب، تأمین و پخش، عمده‌فروشی، تولید، واردات، آموزش و خدمات تخصصی. برند و تلفظ: PETAVU / پِتاو.

[باز کردن پیش‌نمایش خودبسنده](release/PETAVU-preview.html) · [لوگوی SVG](public/brand/petavu-logo.svg)

## تحویل این مرحله

- سایت فارسی RTL با تصویر سه‌بعدی اختصاصی، حلقهٔ تعاملی WebGL، تجربهٔ اسکرول بدون scroll hijacking و reduced-motion.
- نشان و لوگوی SVG قابل‌ویرایش و قابل‌مقیاس؛ فونت‌ها محلی و دارای مجوز همراه.
- مسیر نمایشی عضویت/ورود، انتخاب نقش کسب‌وکار، پروفایل محلی و چند صفحهٔ پنل.
- جست‌وجو و فیلتر روی داده‌های نمونه، جزئیات در modal، draft محلی و export JSONِ پروفایل نمونه.
- پنل اعضا، مدیریت سایت/اعضا، ویترین B2B و مدیریت ویترین؛ build مستقل هر فضا.
- PostgreSQL schema + tenant/RLS + ۱۱ آزمون محلی جداسازی و privilege.
- مستند امنیت، معماری، UI/UX، محتوای برند، بکاپ و انتقال؛ اسکریپت اولیهٔ بکاپ رمزنگاری‌شده و checksum verification.
- static server با کنترل‌های امنیت پایه و Docker، fail-closed برای API پیکربندی‌نشده.

## مرز روشن امکانات

| بخش | وضعیت |
|---|---|
| طراحی و تعاملات frontend | اجرایی در پیش‌نمایش |
| SQL و تست RLS | ساخته و در موتور محلی PGlite آزموده شده |
| پنج artifact مستقل | قابل build؛ DNS/ساب‌دامین واقعی مستقر نیست |
| حساب/ورود/MFA/مدیر واقعی | backend پیاده‌سازی و متصل نشده |
| Supabase/GitHub واقعی | هیچ اتصال یا تغییر انجام نشده |
| تجارت، پرداخت، پیام، دورهٔ آموزشی | فاز بعد، بدون داده/عملیات واقعی |
| بکاپ production و PITR | طرح/اسکریپت؛ scheduler و restore واقعی اجرا نشده |
| ASVS/تست نفوذ | استاندارد هدف؛ گواهی کامل نیست |

**توکن‌ها در هیچ فایل پروژه ذخیره نشده‌اند.** فرم نمایشی رمز دریافت نمی‌کند؛ ایمیل ذخیره نمی‌شود. پروفایل نمونه فقط در sessionStorage همان مرورگر است، نه دیتابیس. این اطلاعات غیرعملیاتی قابل اعتماد برای authorization نیستند.

## اجرا

```bash
npm ci
npm run dev        # bind روی 0.0.0.0:5173؛ محیط توسعه، نه production
npm run typecheck
npm run test:db
npx playwright install --with-deps chromium
npm run test:e2e   # dev server باید روشن باشد
npm run build:all
```

ابزار build در محیط این تحویل با Node 20.20.2 اجرا شد؛ برای استقرار پایدار از تصویر Node 24 این پروژه و بررسی digest استفاده کن. مرورگر و node_modules در snapshot ذخیره نمی‌شوند؛ نصب dependencyها از lockfile تکرارپذیر است.

## پنج فضا در preview

- `/` سایت اصلی
- `/panel/` پنل اعضا؛ `/panel/register` و `/panel/login`
- `/adminpanel/` مدیریت سایت و اعضا
- `/shop/` ویترین همکاری B2B
- `/adminshop/` مدیریت ویترین

دکمهٔ «فضاهای پروژه» پایین صفحه جابه‌جایی را انجام می‌دهد. در preview این‌ها مسیرهای یک origin هستند؛ در production برای هر فضا hostname، session، audience، API role و deploy مستقل لازم است.

## استقرار مستقل

```bash
npm run build:panel
APP_SCOPE=panel PETAVU_MODE=unconfigured PORT=8080 npm run serve

# یا Docker:
docker build --build-arg APP_SCOPE=panel -t petavu-panel .
docker run --rm -p 8080:8080 -e APP_SCOPE=panel -e PETAVU_MODE=unconfigured petavu-panel
```

`PETAVU_BASE_DOMAIN` فقط نام دامنه است، بدون protocol. API اولیه همان-origin `/api` است؛ static server endpointهای واقعی ندارد و پاسخ 503 می‌دهد. برای production BFF واقعی، TLS، vault و proxy لازم‌اند. `compose.example.yaml` مثال ساختار است؛ فعال یا آزمایش Docker نشده است. credentials دیتابیس/Storage/Auth هرگز به public runtime config وارد نشوند.

## نسخهٔ قابل انتقال

`npm run export:preview` یک HTML خودبسنده با فونت، تصویر، CSS و JS تعبیه‌شده می‌سازد. برای مرور آفلاین و آزمایش UI است، نه جایگزین backend یا بکاپ واقعی. routing آن hash-based است تا بدون server نیز بین پنج محیط جابه‌جا شود.

برای بازسازی بسته: `npm run export:preview` سپس `python scripts/package-release.py`. پوشهٔ release شامل HTML پیش‌نمایش، archive کد و manifest است. source دارای AGENTS، migrations، فونت/تصویر و lockfile است. secretهای واقعی، node_modules و build/cache به archive وارد نمی‌شوند.

## قواعد و اسناد

- [قواعد مالک و ادامهٔ کار](AGENTS.md)
- [معماری و تصمیم دیتابیس](docs/ARCHITECTURE.fa.md)
- [امنیت و threat model](docs/SECURITY.fa.md)
- [بکاپ و بازیابی](docs/BACKUP-RUNBOOK.fa.md)
- [انتقال هاست و داده](docs/MIGRATION.fa.md)
- [سیستم طراحی](docs/UI-UX.fa.md)
- [تحقیق و متن برند](docs/CONTENT-RESEARCH.fa.md)
- [نتایج و حدود آزمون‌ها](docs/TEST-RESULTS.fa.md)

## موارد نیازمند تصمیم مالک در فاز بعد

لینک مخزن و project ref غیرمحرمانه؛ دامنه و بازار هدف؛ provider میزبانی و مسیر امن اتصال؛ فرایند بررسی هویت هر حرفه؛ نیازهای واقعی پنل، آموزش و ویترین. برای ادامه توکن را در چت نفرست؛ secrets فقط در رابط امن سرویس استقرار وارد شوند.
