import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
const scopes = ['web','panel','adminpanel','shop','adminshop'];
export default defineConfig(({mode}) => {
 const scope = scopes.includes(mode) ? mode : 'preview';
 return {
  plugins: [react(), {
   name: 'petavu-scope',
   transformIndexHtml(html) { return html.replace('APP_SCOPE', scope); }
  }],
  server: {host:'0.0.0.0',port:5173,strictPort:true,allowedHosts:true},
  preview: {host:'0.0.0.0',port:4173,allowedHosts:true},
  build: {outDir:mode==='export'?'dist/export':`dist/${scope}`,assetsInlineLimit:1500000,cssCodeSplit:false,rolldownOptions:{output:{codeSplitting:mode!=='export'}}}
 };
});
